const pm = require('./backend/services/patternMatcher.js');
console.log(pm.tryMatch("open notepad", null, false));
