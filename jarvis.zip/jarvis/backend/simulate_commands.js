const commands = [
  'open chrome',
  'search for weather in London',
  'shutdown',
  'volume up',
  'screenshot',
  'what time is it'
];

function simulate(command) {
  const text = command.toLowerCase().trim();
  let parsed = { action: 'conversational', target: 'none', reply: 'I heard you.' };
  let shell = null;

  if (text.startsWith('open ')) {
    const target = text.replace(/^open /, '').trim();
    parsed = { action: 'open_app', target, reply: `Opening ${target}.` };
    shell = `start ${target}`;
    if (target.includes('http') || target.includes('.com')) {
      parsed.action = 'open_website';
      shell = `start chrome "${target}"`;
    }
  } else if (text.startsWith('search for ')) {
    const query = encodeURIComponent(text.replace('search for ', '').trim());
    parsed = { action: 'open_website', target: `https://www.google.com/search?q=${query}`, reply: `Searching the web for "${decodeURIComponent(query)}".` };
    shell = `start chrome "https://www.google.com/search?q=${query}"`;
  } else if (text === 'shutdown') {
    parsed = { action: 'shutdown', target: null, reply: 'Shutting down the computer.' };
    shell = 'shutdown /s /t 0';
  } else if (text.includes('volume')) {
    // Map volume commands to a powershell placeholder
    parsed = { action: 'execute_powershell', target: 'Increase system volume by one step', reply: 'Turning the volume up.' };
    shell = 'powershell -Command "<powershell-volume-command>"';
  } else if (text === 'screenshot') {
    parsed = { action: 'open_app', target: 'microsoft.windows.camera:', reply: 'Opening screenshot tool.' };
    shell = 'start ms-screenclip:'; // Windows 10+ screen clip URI
  } else if (text.includes('time')) {
    const now = new Date();
    parsed = { action: 'time', target: null, reply: `It is ${now.toLocaleTimeString()}.` };
  }

  return { command, parsed, shell };
}

(async function run() {
  for (const c of commands) {
    const out = simulate(c);
    console.log('---');
    console.log('Input:', out.command);
    console.log('Parsed JSON:', JSON.stringify(out.parsed, null, 2));
    console.log('Shell (dry-run):', out.shell || 'none');
  }
})();
