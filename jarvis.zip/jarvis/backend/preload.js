const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getSystemContext: () => ipcRenderer.invoke('get-system-context'),
  captureAndReadScreen: () => ipcRenderer.invoke('capture-and-read-screen'),
  restoreDashboard: () => ipcRenderer.send('restore-dashboard'),
  quitApp: () => ipcRenderer.send('quit-app')
});
