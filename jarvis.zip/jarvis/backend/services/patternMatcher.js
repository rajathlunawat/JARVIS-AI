/**
 * PatternMatcher - Lightning-fast regex-based command parser for JARVIS
 * 
 * Handles ~80% of common commands instantly (< 1ms) without needing any AI model.
 * Falls through to the Ollama LLM only for conversational/knowledge queries.
 * 
 * @module patternMatcher
 */

'use strict';

const WEBSITE_ALIASES = {
  'youtube': 'https://www.youtube.com',
  'google': 'https://www.google.com',
  'gmail': 'https://mail.google.com',
  'github': 'https://github.com',
  'twitter': 'https://twitter.com',
  'x': 'https://twitter.com',
  'instagram': 'https://www.instagram.com',
  'facebook': 'https://www.facebook.com',
  'whatsapp': 'https://web.whatsapp.com',
  'whatsapp web': 'https://web.whatsapp.com',
  'reddit': 'https://www.reddit.com',
  'linkedin': 'https://www.linkedin.com',
  'netflix': 'https://www.netflix.com',
  'amazon': 'https://www.amazon.in',
  'flipkart': 'https://www.flipkart.com',
  'spotify': 'https://open.spotify.com',
  'chatgpt': 'https://chat.openai.com',
  'stack overflow': 'https://stackoverflow.com',
  'stackoverflow': 'https://stackoverflow.com',
  'wikipedia': 'https://www.wikipedia.org',
};

const APP_ALIASES = {
  'notepad': 'notepad',
  'calculator': 'calc',
  'calc': 'calc',
  'paint': 'mspaint',
  'word': 'winword',
  'microsoft word': 'winword',
  'excel': 'excel',
  'powerpoint': 'powerpnt',
  'microsoft powerpoint': 'powerpnt',
  'chrome': 'chrome',
  'google chrome': 'chrome',
  'firefox': 'firefox',
  'edge': 'msedge',
  'microsoft edge': 'msedge',
  'file explorer': 'explorer',
  'explorer': 'explorer',
  'terminal': 'wt',
  'windows terminal': 'wt',
  'cmd': 'cmd',
  'powershell': 'powershell',
  'task manager': 'taskmgr',
  'control panel': 'control',
  'settings': 'ms-settings:',
  'camera': 'microsoft.windows.camera:',
  'teams': 'msteams:',
  'code': 'code',
  'vs code': 'code',
  'visual studio code': 'code',
  'visual studio': 'code',
  'snipping tool': 'snippingtool',
  'spotify': 'spotify',
  'slack': 'slack',
  'discord': 'discord',
};

const fs = require('fs');
const path = require('path');
const learning = require('./learning');

function _inferPreviousTarget(chatHistory) {
  if (!Array.isArray(chatHistory) || chatHistory.length === 0) return null;

  const reversed = chatHistory.slice().reverse();
  for (const entry of reversed) {
    if (!entry || !entry.sender || !entry.text) continue;
    const text = entry.text.toLowerCase().trim();

    // Prefer user commands only
    if (entry.sender !== 'user') continue;

    const openMatch = text.match(/^(?:open|go to|launch|visit|navigate to)\s+(.+?)(?:\s+(?:website|site|page|for me))?$/i);
    if (openMatch) {
      const siteName = openMatch[1].replace(/\s*(website|site|page|for me)\s*/gi, '').trim();
      if (siteName) return siteName;
    }

    const openSuffixMatch = text.match(/^(.+?)\s+open(?:\s+(?:website|site|page|for me))?$/i);
    if (openSuffixMatch) {
      return openSuffixMatch[1].trim();
    }

    const searchMatch = text.match(/^(?:search|search for|google|look up|find)\s+(.+)/i);
    if (searchMatch) {
      return searchMatch[1].trim();
    }
  }

  return null;
}

const HINDI_REPLACEMENTS = [
  { from: /\b(kholo|khol do|kholna|open karo|start karo|launch karo|run karo)\b/g, to: 'open' },
  { from: /\b(khoj karo|search karo|talash karo|dhoondo|dhoondho|google karo)\b/g, to: 'search' },
  { from: /\b(band karo|band kar do|close karo|quit karo|exit karo|nikal do|qit karo)\b/g, to: 'close' },
  { from: /\b(shut down|shutdown|shut karo|system bandh karo|computer band karo|pc bandh karo|laptop band karo)\b/g, to: 'shutdown' },
  { from: /\b(restart karo|reboot karo|fir se shuru karo|dobara shuru karo)\b/g, to: 'restart' },
  { from: /\b(so jao|sleep karo|sleep mode|suspend karo|suspend)\b/g, to: 'sleep' },
  { from: /\b(lock karo|lock kar do|screen lock karo|screen bandh karo)\b/g, to: 'lock' },
  { from: /\b(volume badhao|awaz badhao|aawaz badhao|tez karo|tezz karo)\b/g, to: 'increase volume' },
  { from: /\b(volume kam karo|awaz kam karo|aawaz kam karo|dhimi karo|kam karo)\b/g, to: 'decrease volume' },
  { from: /\b(mute karo|mute kar do|sound band karo|aawaaz band karo|awaaz bandh karo)\b/g, to: 'mute' },
  { from: /\b(screenshot lo|screenshot kheencho|screen capture karo|chitra lo|photo lo)\b/g, to: 'screenshot' },
  { from: /\b(kitne baje hain|samay kya hai|samay batao|time batao|abhi kya samay hua hai)\b/g, to: 'what is the time' },
  { from: /\b(tarikh kya hai|aaj ki tarikh kya hai|date batao|aaj ka din kya hai)\b/g, to: 'what is the date' },
  { from: /\b(yaad dilao|yaad dilana|remind me|remind karo|mujhe yaad dilao|mujhe yaad dilana)\b/g, to: 'remind me' },
  { from: /\b(dhanyavaad|shukriya|thanks|thank you|thx|cheers)\b/g, to: 'thank you' },
  { from: /\b(namaste|namaskar|kaise ho|kya haal hai|subh prabhat|shubh prabhat)\b/g, to: 'hello' },
];

function _normalizeCommand(text) {
  let normalized = text;
  HINDI_REPLACEMENTS.forEach((item) => {
    normalized = normalized.replace(item.from, item.to);
  });
  normalized = normalized.replace(/\b(minute|mins|minute ke baad|minutes|minute mein|minutes mein|minute me|minutes me)\b/g, 'minutes');
  normalized = normalized.replace(/\b(seconds|second|second ke baad|seconds mein|second me)\b/g, 'seconds');
  normalized = normalized.replace(/\b(hours|hour|ghante|ghanta|ghante mein|ghante ke baad)\b/g, 'hours');
  normalized = normalized.replace(/\b(in|mein|mein\s*)\b/g, 'in ');
  return normalized;
}

/**
 * Attempts to match user text against known command patterns.
 * Returns a response object if matched, or null if no pattern matches
 * (caller should fall through to AI).
 * 
 * @param {string} text - Raw user input text
 * @param {import('socket.io').Socket} socket - WebSocket for reminders
 * @param {boolean} dryRun - If true, don't execute system commands
 * @returns {Object|null} Response object or null
 */
function _getLastUserCommand(chatHistory) {
  if (!Array.isArray(chatHistory) || chatHistory.length === 0) return null;
  const userEntries = chatHistory.filter((entry) => entry && entry.sender === 'user');
  return userEntries.length >= 2 ? userEntries[userEntries.length - 2].text : null;
}

function _resolveTargetType(target) {
  const lower = target.toLowerCase().trim();
  if (lower.startsWith('http') || lower.includes('.') || WEBSITE_ALIASES[lower] || lower.endsWith(':')) {
    return 'website';
  }
  return 'app';
}

function tryMatch(text, socket, dryRun = false, chatHistory = []) {
  const lower = text.toLowerCase().trim();
  const normalized = _normalizeCommand(lower);

  // --- Learned command mapping ---
  const learned = learning.findMapping(text);
  if (learned) {
    if (learned.type === 'website') {
      return _openWebsite(learned.target, learned.trigger, dryRun);
    }
    return _openApp(learned.target, learned.trigger, dryRun);
  }

  // --- Learn a new mapping explicitly ---
  const learnMatch = normalized.match(/^(?:learn|remember|from now on|when i say)\s+(.+?)\s+(?:means|mean|should open|should launch|should start|should run|is)\s+(.+)$/i);
  if (learnMatch) {
    const trigger = learnMatch[1].trim();
    const target = learnMatch[2].trim();
    const type = _resolveTargetType(target);
    learning.addCommandMapping(trigger, target, type, 'user taught command mapping');
    return { type: 'success', text: `Got it. When you say "${trigger}", I will open ${type === 'website' ? 'the website' : 'the app'} "${target}".`, action: null };
  }

  // --- Correction after mistake ---
  const correctionMatch = normalized.match(/^(?:no,? |nah,? |not that,? |actually,? |i meant|rather|instead)(?:\s*(?:open|start|launch|run))?\s*(.+)$/i);
  if (correctionMatch) {
    const correctedTarget = correctionMatch[1].trim();
    const previousCommand = _getLastUserCommand(chatHistory);
    if (previousCommand) {
      const type = _resolveTargetType(correctedTarget);
      learning.addCommandMapping(previousCommand, correctedTarget, type, 'user correction after mistake');
      return { type: 'success', text: `Understood. When you say "${previousCommand}", I will now open "${correctedTarget}".`, action: null };
    }
    return { type: 'error', text: 'I understood the correction, but I need the previous command context to learn from it.', action: null };
  }

  // --- Open App ---
  const openAppMatch = normalized.match(/^(?:open|start|launch|run)\s+(.+?)(?:\s+app)?$/i);
  if (openAppMatch) {
    const appInput = openAppMatch[1].replace(/\s*app\s*/gi, '').trim();
    const appKey = appInput.toLowerCase();
    
    // Check if it's actually a website alias
    if (WEBSITE_ALIASES[appKey]) {
      return _openWebsite(WEBSITE_ALIASES[appKey], appKey, dryRun);
    }
    
    const target = APP_ALIASES[appKey] || appInput;
    return _openApp(target, appInput, dryRun);
  }

  // --- Open Website ---
  const openSiteMatch = normalized.match(/^(?:open|go to|launch|visit|navigate to)\s+(.+?)(?:\s+(?:website|site|page|for me))?$/i);
  if (openSiteMatch) {
    const siteName = openSiteMatch[1].replace(/\s*(website|site|page|for me)\s*/gi, '').trim();
    
    // Check aliases first
    const alias = WEBSITE_ALIASES[siteName];
    if (alias) {
      return _openWebsite(alias, siteName, dryRun);
    }

    // Check if it looks like a URL
    if (siteName.includes('.') || siteName.startsWith('http')) {
      let url = siteName;
      if (!url.startsWith('http')) url = 'https://' + url;
      return _openWebsite(url, siteName, dryRun);
    }

    // Check if it's an app instead
    const appName = siteName.toLowerCase().replace('.exe', '');
    if (APP_ALIASES[appName]) {
      return _openApp(APP_ALIASES[appName], appName, dryRun);
    }

    // Default: search Google
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(siteName)}`;
    return _openWebsite(searchUrl, siteName, dryRun);
  }

  const contextReferentMatch = normalized.match(/^(?:open|go to|launch|visit|navigate to)\s+(?:that|there|it|the same|the previous|this)(?:\s+(?:website|site|page))?$/i);
  if (contextReferentMatch) {
    const previousTarget = _inferPreviousTarget(chatHistory);
    if (previousTarget) {
      const alias = WEBSITE_ALIASES[previousTarget];
      if (alias) {
        return _openWebsite(alias, previousTarget, dryRun);
      }
      if (previousTarget.includes('.') || previousTarget.startsWith('http')) {
        let url = previousTarget;
        if (!url.startsWith('http')) url = 'https://' + url;
        return _openWebsite(url, previousTarget, dryRun);
      }
      if (APP_ALIASES[previousTarget.toLowerCase()]) {
        return _openApp(APP_ALIASES[previousTarget.toLowerCase()], previousTarget, dryRun);
      }
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(previousTarget)}`;
      return _openWebsite(searchUrl, previousTarget, dryRun);
    }

    return { type: 'error', text: 'Mujhe yaad nahi raha kaunsa website tha, boss. Naam dobara bolo.', action: null };
  }

  // --- Open Website (Hindi suffix commands like "youtube kholo") ---
  const openSiteSuffixMatch = normalized.match(/^(.+?)\s+open(?:\s+(?:website|site|page|for me))?$/i);
  if (openSiteSuffixMatch) {
    const siteName = openSiteSuffixMatch[1].trim();
    const alias = WEBSITE_ALIASES[siteName];
    if (alias) {
      return _openWebsite(alias, siteName, dryRun);
    }
    if (siteName.includes('.') || siteName.startsWith('http')) {
      let url = siteName;
      if (!url.startsWith('http')) url = 'https://' + url;
      return _openWebsite(url, siteName, dryRun);
    }
    if (APP_ALIASES[siteName]) {
      return _openApp(APP_ALIASES[siteName], siteName, dryRun);
    }
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(siteName)}`;
    return _openWebsite(searchUrl, siteName, dryRun);
  }

  // --- Search for something ---
  const searchMatch = normalized.match(/^(?:search|search for|google|look up|find)\s+(.+)/i);
  if (searchMatch) {
    const query = searchMatch[1].trim();
    const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    return _openWebsite(url, `search: ${query}`, dryRun);
  }

  // --- Close App ---
  const closeMatch = normalized.match(/^(?:close|kill|stop|quit|exit|end)\s+(.+)/i);
  if (closeMatch) {
    let processName = closeMatch[1].trim().toLowerCase();
    // Friendly names to process names
    const closeAliases = {
      'chrome': 'chrome.exe', 'google chrome': 'chrome.exe',
      'firefox': 'firefox.exe', 'notepad': 'notepad.exe',
      'word': 'winword.exe', 'excel': 'excel.exe',
      'teams': 'teams.exe', 'edge': 'msedge.exe',
      'explorer': 'explorer.exe', 'file explorer': 'explorer.exe',
      'task manager': 'taskmgr.exe', 'spotify': 'spotify.exe',
      'code': 'code.exe', 'vs code': 'code.exe',
      'website': 'chrome.exe', 'browser': 'chrome.exe',
    };
    processName = closeAliases[processName] || (processName.endsWith('.exe') ? processName : processName + '.exe');
    
    const cmd = `taskkill /IM ${processName} /F`;
    if (dryRun) return { type: 'success', text: `Preparing to close ${processName}...`, action: 'app_close_dry', dryCommand: cmd };
    _exec(cmd);
    return { type: 'success', text: `${processName} has been closed.`, action: 'app_closed' };
  }

  const closeSuffixMatch = normalized.match(/^(.+?)\s+close$/i);
  if (closeSuffixMatch) {
    let processName = closeSuffixMatch[1].trim().toLowerCase();
    const closeAliases = {
      'chrome': 'chrome.exe', 'google chrome': 'chrome.exe',
      'firefox': 'firefox.exe', 'notepad': 'notepad.exe',
      'word': 'winword.exe', 'excel': 'excel.exe',
      'teams': 'teams.exe', 'edge': 'msedge.exe',
      'explorer': 'explorer.exe', 'file explorer': 'explorer.exe',
      'task manager': 'taskmgr.exe', 'spotify': 'spotify.exe',
      'code': 'code.exe', 'vs code': 'code.exe',
      'website': 'chrome.exe', 'browser': 'chrome.exe',
    };
    processName = closeAliases[processName] || (processName.endsWith('.exe') ? processName : processName + '.exe');
    const cmd = `taskkill /IM ${processName} /F`;
    if (dryRun) return { type: 'success', text: `Preparing to close ${processName}...`, action: 'app_close_dry', dryCommand: cmd };
    _exec(cmd);
    return { type: 'success', text: `${processName} has been closed.`, action: 'app_closed' };
  }

  // --- Shutdown ---
  if (/^(shut\s*down|power\s*off|turn\s*off)(\s+the)?(\s+computer|\s+pc|\s+laptop|\s+system)?$/i.test(lower)) {
    const cmd = 'shutdown /s /t 0';
    if (dryRun) return { type: 'success', text: 'Preparing to shut down the system...', action: 'shutdown_dry', dryCommand: cmd };
    _exec(cmd);
    return { type: 'success', text: 'Shutting down now.', action: 'shutdown' };
  }

  // --- Restart ---
  if (/^(restart|reboot)(\s+the)?(\s+computer|\s+pc|\s+laptop|\s+system)?$/i.test(lower)) {
    const cmd = 'shutdown /r /t 0';
    if (dryRun) return { type: 'success', text: 'Preparing to restart the system...', action: 'restart_dry', dryCommand: cmd };
    _exec(cmd);
    return { type: 'success', text: 'Restarting now.', action: 'restart' };
  }

  // --- Sleep / Lock ---
  if (/^(sleep|lock)(\s+the)?(\s+computer|\s+pc|\s+laptop|\s+system|\s+screen)?$/i.test(lower)) {
    const cmd = lower.includes('lock') ? 'rundll32.exe user32.dll,LockWorkStation' : 'rundll32.exe powrprof.dll,SetSuspendState 0,1,0';
    if (dryRun) return { type: 'success', text: 'Preparing to lock or suspend the system...', action: 'sleep_dry', dryCommand: cmd };
    _exec(cmd);
    return { type: 'success', text: lower.includes('lock') ? 'Screen locked.' : 'System is entering sleep mode.', action: 'sleep' };
  }

  // --- Volume Control ---
  const volUpMatch = /^(?:increase|raise|turn up|volume up|louder)(?:\s+the)?(?:\s+volume)?/i.test(lower);
  const volDownMatch = /^(?:decrease|lower|turn down|volume down|quieter|softer)(?:\s+the)?(?:\s+volume)?/i.test(lower);
  const muteMatch = /^(mute|unmute|toggle mute)(?:\s+the)?(?:\s+volume|\s+sound|\s+audio)?$/i.test(lower);

  if (volUpMatch || volDownMatch || muteMatch) {
    let psCmd;
    let reply;
    const sendMsg = `Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);' -Name Win -Namespace Native`;

    if (volUpMatch) {
      psCmd = `${sendMsg}; [Native.Win]::SendMessageW([IntPtr]::Zero,0x319,[IntPtr]::Zero,[IntPtr]0x0a0000)`;
      reply = 'Increasing volume.';
    } else if (volDownMatch) {
      psCmd = `${sendMsg}; [Native.Win]::SendMessageW([IntPtr]::Zero,0x319,[IntPtr]::Zero,[IntPtr]0x090000)`;
      reply = 'Decreasing volume.';
    } else {
      psCmd = `${sendMsg}; [Native.Win]::SendMessageW([IntPtr]::Zero,0x319,[IntPtr]::Zero,[IntPtr]0x080000)`;
      reply = 'Muting or unmuting audio.';
    }

    const fullCmd = `powershell -Command "${psCmd.replace(/"/g, '\\"')}"`;
    if (dryRun) return { type: 'success', text: reply, action: 'powershell_dry', dryCommand: fullCmd };
    _exec(fullCmd);
    return { type: 'success', text: reply, action: 'powershell_executed' };
  }

  // --- Screenshot ---
  if (/^(?:take|capture|grab)?\s*(?:a\s+)?screenshot/i.test(lower)) {
    const psCmd = `Add-Type -AssemblyName System.Windows.Forms,System.Drawing; $bmp=[System.Drawing.Bitmap]::new([System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width,[System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height); $g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen(0,0,0,0,$bmp.Size); $path=[Environment]::GetFolderPath('MyPictures') + '\\screenshot-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.png'; $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png); $g.Dispose(); $bmp.Dispose(); Write-Output $path`;
    const fullCmd = `powershell -Command "${psCmd.replace(/"/g, '\\"')}"`;
    if (dryRun) return { type: 'success', text: 'Taking a screenshot...', action: 'powershell_dry', dryCommand: fullCmd };
    _exec(fullCmd);
    return { type: 'success', text: 'Screenshot saved to your Pictures folder.', action: 'powershell_executed' };
  }

  // --- Time / Date ---
  if (/^(?:what(?:'s| is)?\s+the\s+)?(?:time|date|day)(?:\s+(?:is it|today|now|right now))?[.?!]*$/i.test(lower)) {
    const now = new Date();
    return { type: 'info', text: `It is ${now.toLocaleTimeString()}, ${now.toLocaleDateString()}.`, action: null };
  }

  // --- Set Reminder ---
  const reminderMatch = lower.match(/^(?:remind me|set (?:a )?(?:reminder|timer|alarm))(?:\s+to)?\s+(.+?)\s+in\s+(\d+)\s*(seconds?|minutes?|hours?|mins?|hrs?|secs?)/i);
  if (reminderMatch) {
    const message = reminderMatch[1].trim();
    const amount = parseInt(reminderMatch[2]);
    const unit = reminderMatch[3].toLowerCase();
    
    let multiplier = 1000; // seconds
    if (unit.startsWith('min')) multiplier = 60000;
    else if (unit.startsWith('hr') || unit.startsWith('hour')) multiplier = 3600000;

    const delayMs = amount * multiplier;

    setTimeout(() => {
      if (socket && socket.connected) {
        socket.emit('response', {
          type: 'reminder',
          text: `Sir, you asked me to remind you: ${message}`,
          action: 'reminder_trigger'
        });
      }
    }, delayMs);

    const unitDisplay = unit.startsWith('sec') ? 'seconds' : unit.startsWith('min') ? 'minutes' : 'hours';
    return { type: 'success', text: `Reminder set for ${amount} ${unitDisplay}. I will remind you to ${message}.`, action: 'reminder_set' };
  }

  // --- Alternative reminder format: "remind me in 5 minutes to ..." ---
  const reminderMatch2 = lower.match(/^(?:remind me|set (?:a )?(?:reminder|timer))?\s*in\s+(\d+)\s*(seconds?|minutes?|hours?|mins?|hrs?|secs?)\s+(?:to\s+)?(.+)/i);
  if (reminderMatch2) {
    const amount = parseInt(reminderMatch2[1]);
    const unit = reminderMatch2[2].toLowerCase();
    const message = reminderMatch2[3].trim();

    let multiplier = 1000;
    if (unit.startsWith('min')) multiplier = 60000;
    else if (unit.startsWith('hr') || unit.startsWith('hour')) multiplier = 3600000;

    const delayMs = amount * multiplier;

    setTimeout(() => {
      if (socket && socket.connected) {
        socket.emit('response', {
          type: 'reminder',
          text: `Sir, you asked me to remind you: ${message}`,
          action: 'reminder_trigger'
        });
      }
    }, delayMs);

    const unitDisplay = unit.startsWith('sec') ? 'seconds' : unit.startsWith('min') ? 'minutes' : 'hours';
    return { type: 'success', text: `Reminder set for ${amount} ${unitDisplay}. I will remind you to ${message}.`, action: 'reminder_set' };
  }

  // --- Greetings (instant, no AI needed) ---
  if (/^(hello|hi|hey|good morning|good afternoon|good evening|howdy|sup|yo|what's up|hola)\s*(?:jarvis)?[.!]*$/i.test(lower)) {
    const hour = new Date().getHours();
    let greeting;
    if (hour < 12) greeting = 'Good morning';
    else if (hour < 17) greeting = 'Good afternoon';
    else greeting = 'Good evening';
    
    const replies = [
      `${greeting}. How may I assist you today?`,
      `${greeting}. I am ready to help.`,
      `${greeting}. Please tell me what you would like to do next.`,
      `${greeting}. I am available for your request.`,
      `${greeting}. Let me know how I can assist you.`,
    ];
    return { type: 'info', text: replies[Math.floor(Math.random() * replies.length)], action: null };
  }

  // --- Thank you ---
  if (/^(thanks?|thank you|thx|cheers|appreciate it)(?:\s+jarvis)?[.!]*$/i.test(lower)) {
    const replies = [
      "You're welcome. Let me know if you need anything else.",
      "My pleasure. I am here to help.",
      "Happy to assist. Please ask if you need anything further.",
      "Certainly. I am available for any additional requests.",
      "Glad to assist. Let me know if there is anything more I can do.",
    ];
    return { type: 'info', text: replies[Math.floor(Math.random() * replies.length)], action: null };
  }

  // No pattern matched — fall through to AI
  return null;
}

// --- Internal helpers ---

const { exec } = require('child_process');

function _exec(cmd) {
  console.log(`💻 Executing: ${cmd}`);
  exec(cmd, (error, stdout, stderr) => {
    if (error) console.error(`❌ Shell error: ${error.message}`);
    else if (stderr) console.error(`⚠️ Shell stderr: ${stderr}`);
    else console.log(`✅ Shell success: ${stdout.trim() || 'No output'}`);
  });
}

function _openWebsite(url, label, dryRun) {
  const cmd = `start chrome "${url}"`;
  if (dryRun) return { type: 'success', text: `Preparing to open ${label}...`, action: 'browser_dry', dryCommand: cmd };
  _exec(cmd);
  return { type: 'success', text: `${label} is opening now.`, action: 'browser_opened' };
}

function _openApp(target, label, dryRun) {
  // Use empty quotes for title to prevent start from misinterpreting quoted paths
  const cmd = `start "" "${target}"`;
  if (dryRun) return { type: 'success', text: `Preparing to open ${label}...`, action: 'app_dry', dryCommand: cmd };
  _exec(cmd);
  return { type: 'success', text: `${label} is opening now.`, action: 'app_opened' };
}

module.exports = { tryMatch };
