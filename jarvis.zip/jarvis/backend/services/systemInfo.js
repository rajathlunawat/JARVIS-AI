const si = require('systeminformation');

let pollingInterval = null;

/**
 * Starts polling system information and sending it to the client
 * @param {import('socket.io').Socket} socket 
 */
function startPolling(socket) {
  // Clear any existing interval
  if (pollingInterval) clearInterval(pollingInterval);

  console.log('📊 Started system polling');

  // Poll every 2 seconds
  pollingInterval = setInterval(async () => {
    try {
      // Get CPU usage
      const currentLoad = await si.currentLoad();
      const cpuValue = Math.round(currentLoad.currentLoad);

      // Get RAM usage
      const mem = await si.mem();
      const ramValue = Math.round((mem.active / mem.total) * 100);

      // Get Battery status
      const battery = await si.battery();
      const batteryValue = battery.hasBattery ? battery.percent : 100;
      const isCharging = battery.hasBattery ? battery.isCharging : true;

      // Get Disk usage (just the main drive, usually C: on Windows)
      const fsSize = await si.fsSize();
      const mainDrive = fsSize.length > 0 ? fsSize[0] : null;
      const diskValue = mainDrive ? Math.round(mainDrive.use) : 0;

      // Send to frontend
      socket.emit('systemStats', {
        cpu: cpuValue,
        ram: ramValue,
        battery: batteryValue,
        isCharging: isCharging,
        disk: diskValue
      });
    } catch (error) {
      console.error('❌ Error polling system stats:', error);
    }
  }, 2000);
}

/**
 * Stops polling system information
 */
function stopPolling() {
  if (pollingInterval) {
    clearInterval(pollingInterval);
    pollingInterval = null;
    console.log('📊 Stopped system polling');
  }
}

/**
 * Fetches the current system stats on demand (synchronous wrapper for async fetch)
 * @returns {Promise<Object>} The system stats
 */
async function getCurrentStats() {
  try {
    const battery = await si.battery();
    const batteryValue = battery.hasBattery ? battery.percent : 100;
    const isCharging = battery.hasBattery ? battery.isCharging : true;
    
    return {
      battery: batteryValue,
      isCharging: isCharging,
    };
  } catch (error) {
    console.error('Error fetching on-demand stats:', error);
    return { battery: 'unknown', isCharging: 'unknown' };
  }
}

module.exports = {
  startPolling,
  stopPolling,
  getCurrentStats
};
