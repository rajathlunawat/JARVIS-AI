const fs = require('fs');
const path = require('path');

const PREF_FILE = path.join(__dirname, '../preferences.json');

/**
 * Loads user preferences from disk.
 * @returns {Object}
 */
function loadPreferences() {
  try {
    if (!fs.existsSync(PREF_FILE)) {
      return {};
    }
    const data = fs.readFileSync(PREF_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error loading preferences:', err);
    return {};
  }
}

/**
 * Updates a single preference key-value pair and saves to disk.
 * @param {string} key 
 * @param {string} value 
 */
function updatePreference(key, value) {
  try {
    const prefs = loadPreferences();
    prefs[key] = value;
    fs.writeFileSync(PREF_FILE, JSON.stringify(prefs, null, 2));
    console.log(`💾 Saved preference: ${key} = ${value}`);
  } catch (err) {
    console.error('Error saving preference:', err);
  }
}

/**
 * Converts preferences to a readable string for the AI prompt.
 * @returns {string}
 */
function getPreferencesString() {
  const prefs = loadPreferences();
  const keys = Object.keys(prefs);
  if (keys.length === 0) return "No specific user preferences saved yet.";
  
  return keys.map(k => `- ${k}: ${prefs[k]}`).join('\n');
}

module.exports = {
  loadPreferences,
  updatePreference,
  getPreferencesString
};
