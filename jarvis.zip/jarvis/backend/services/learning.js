const fs = require('fs');
const path = require('path');

const LEARNING_FILE = path.join(__dirname, '../learning.json');

function loadLearning() {
  try {
    if (!fs.existsSync(LEARNING_FILE)) {
      return { mappings: [] };
    }
    const data = fs.readFileSync(LEARNING_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error loading learning data:', err);
    return { mappings: [] };
  }
}

function saveLearning(data) {
  try {
    fs.writeFileSync(LEARNING_FILE, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('Error saving learning data:', err);
  }
}

function _normalize(text) {
  return String(text || '').toLowerCase().trim();
}

function _escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function addCommandMapping(trigger, target, type = 'app', note = '') {
  const learning = loadLearning();
  const normalizedTrigger = _normalize(trigger);
  const now = new Date().toISOString();

  let entry = learning.mappings.find((item) => _normalize(item.trigger) === normalizedTrigger);
  if (entry) {
    entry.target = target;
    entry.type = type;
    entry.note = note || entry.note;
    entry.updatedAt = now;
  } else {
    entry = {
      trigger: trigger.trim(),
      target: target.trim(),
      type,
      note,
      createdAt: now,
      updatedAt: now,
    };
    learning.mappings.push(entry);
  }

  saveLearning(learning);
  return entry;
}

function findMapping(input) {
  const normalizedInput = _normalize(input);
  const learning = loadLearning();
  return learning.mappings.find((entry) => {
    const trigger = _normalize(entry.trigger);
    if (!trigger) return false;
    const regex = new RegExp(`\\b${_escapeRegExp(trigger)}\\b`, 'i');
    return regex.test(normalizedInput);
  });
}

function getLearningString() {
  const learning = loadLearning();
  if (!Array.isArray(learning.mappings) || learning.mappings.length === 0) {
    return 'No user corrections or learned command mappings yet.';
  }

  return learning.mappings
    .map((entry) => `- When the user says "${entry.trigger}", prefer ${entry.type === 'website' ? 'website' : 'app'} "${entry.target}"${entry.note ? ` (${entry.note})` : ''}`)
    .join('\n');
}

module.exports = {
  loadLearning,
  saveLearning,
  addCommandMapping,
  findMapping,
  getLearningString,
};
