const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { Server } = require('socket.io');
const cors = require('cors');
// Removed dotenv since no API keys are needed anymore

// Initialize Express app
const app = express();
const server = http.createServer(app);

// Configure Socket.IO
const io = new Server(server, {
  cors: {
    origin: "*", // Allow frontend to connect from anywhere (since it's a local desktop app)
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());

// Serve a real favicon (SVG) when browsers request /favicon.ico
app.get('/favicon.ico', (req, res) => {
  const faviconPath = path.join(__dirname, '../frontend/favicon.svg');
  res.sendFile(faviconPath, (err) => {
    if (err) {
      // Fallback to no-content if file missing
      res.status(204).end();
    }
  });
});

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Routes
app.get('/api/status', (req, res) => {
  res.json({ status: 'online', version: '1.0.0' });
});

const multer = require('multer');
const pdfParse = require('pdf-parse');
const sharp = require('sharp');
const Tesseract = require('tesseract.js');
const upload = multer({ storage: multer.memoryStorage() });

app.post('/api/upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  try {
    let extractedText = '';
    const fileExt = path.extname(req.file.originalname).toLowerCase();
    const fileSizeKB = Math.round(req.file.size / 1024);
    
    console.log(`📄 File upload: ${req.file.originalname} (${fileSizeKB} KB, type: ${req.file.mimetype})`);
    
    if (fileExt === '.pdf') {
      try {
        const pdfData = await pdfParse(req.file.buffer);
        extractedText = (pdfData.text || '').trim();
        if (extractedText) {
          // Normalize whitespace so the text is easier to process.
          extractedText = extractedText.replace(/\s+/g, ' ').trim();
        }
        console.log(`📄 PDF parsed: ${pdfData.numpages} pages, ${extractedText.length} chars extracted`);
        
        if (!extractedText || extractedText.length < 50) {
          // PDF exists but has no extractable text (likely scanned/image-based)
          try {
            console.log('🔍 Attempting OCR fallback for PDF...');
            const imageBuffer = await sharp(req.file.buffer, { density: 200 })
              .png()
              .toBuffer();
            const { data: { text: ocrText } } = await Tesseract.recognize(imageBuffer, 'eng');
            const normalizedOcrText = (ocrText || '').replace(/\s+/g, ' ').trim();
            if (normalizedOcrText.length > 20) {
              extractedText = normalizedOcrText;
              console.log(`🔍 OCR fallback succeeded: ${extractedText.length} chars extracted`);
            } else {
              extractedText = `[This PDF has ${pdfData.numpages || 'unknown number of'} page(s) but contains no extractable text or the extracted text was too short. It may be a scanned document or image-based PDF. File size: ${fileSizeKB} KB.]`;
            }
          } catch (ocrErr) {
            console.warn('PDF OCR fallback failed:', ocrErr.message);
            extractedText = `[This PDF has ${pdfData.numpages || 'unknown number of'} page(s) but contains no extractable text. OCR fallback also failed: ${ocrErr.message}. File size: ${fileSizeKB} KB.]`;
          }
        }
      } catch (pdfErr) {
        console.error('PDF parse error:', pdfErr.message);
        extractedText = `[Failed to extract text from this PDF: ${pdfErr.message}. The file is ${fileSizeKB} KB. It may be corrupted or in an unsupported format.]`;
      }
    } else if (['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.svg'].includes(fileExt)) {
      // Image files - can't extract text but acknowledge them
      extractedText = `[This is an image file: ${req.file.originalname} (${fileSizeKB} KB, ${req.file.mimetype}). Image analysis is not available in offline mode.]`;
    } else {
      // Treat as plain text (.txt, .js, .py, .html, .css, .json, .csv, .log, etc.)
      extractedText = req.file.buffer.toString('utf-8').trim();
      if (!extractedText) {
        extractedText = `[This file appears to be empty: ${req.file.originalname}]`;
      }
    }

    res.json({ 
      success: true, 
      text: extractedText.substring(0, 15000),
      filename: req.file.originalname,
      fileSize: fileSizeKB
    });
  } catch (error) {
    console.error('File parsing error:', error);
    res.status(500).json({ error: `Failed to parse file: ${error.message}` });
  }
});

// Services
const systemInfo = require('./services/systemInfo');
const commandParser = require('./services/commandParser');

// Check Ollama Health, load STT model, then start server
const { pipeline, env } = require('@xenova/transformers');
// Use local caching for offline use
env.allowLocalModels = true;

let transcriber = null;

async function startBackend() {
  const isOllamaRunning = await commandParser.checkOllamaHealth();
  const PORT = process.env.PORT || 3000;
  
  server.listen(PORT, async () => {
    console.log(`
  🤖 JARVIS Backend Server is running!
  🌐 API: http://localhost:${PORT}
  ⚡ WebSocket: ws://localhost:${PORT}
    `);
    
    if (!isOllamaRunning) {
      console.log('⚠️ WARNING: Ollama is not running. Conversational queries will fail until you start Ollama.');
    }

    console.log('⏳ Loading Offline Speech-to-Text Model (Whisper) with multilingual support...');
    try {
      transcriber = await pipeline('automatic-speech-recognition', 'Xenova/whisper-tiny');
      console.log('✅ Offline multilingual STT model loaded successfully!');
    } catch (e) {
      console.error('❌ Failed to load Offline STT model:', e);
    }
  });
}

// Add transcribe_audio listener to the existing connection handler
io.on('connection', (socket) => {
  console.log('📱 Frontend connected via WebSocket:', socket.id);
  
  // Start sending real system stats when a client connects
  systemInfo.startPolling(socket);

  socket.on('transcribe_audio', async (audioBuffer) => {
    if (!transcriber) {
      socket.emit('transcribe_error', 'Offline STT model is still loading or failed to load.');
      return;
    }
    try {
      const float32Data = new Float32Array(audioBuffer);
      const result = await transcriber(float32Data);
      const text = result.text.trim();
      if (text) {
        console.log(`🎤 Voice transcribed: "${text}"`);
        socket.emit('transcribe_result', text);
      }
    } catch (error) {
      console.error('❌ Transcription error:', error);
      socket.emit('transcribe_error', 'Failed to process audio.');
    }
  });

  // Handle incoming commands from frontend
  socket.on('command', async (data) => {
    console.log(`🗣️ Command received: "${data.text}"`);
    const dryRun = !!data.dryRun;
    try {
      // Parse and optionally execute command (dryRun disables execution)
      const response = await commandParser.processCommand(data.text, socket, dryRun, data.fileContext, data.chatHistory || []);

      // Send response back
      socket.emit('response', response);
    } catch (error) {
      console.error('❌ Error processing command:', error);
      socket.emit('response', {
        type: 'error',
        text: 'Sorry, I encountered an error while processing that command.',
        action: null
      });
    }
  });

  socket.on('vision_command', async (data) => {
    console.log(`📷 Vision command received`);
    socket.emit('response', {
      type: 'error',
      text: 'Sorry sir, my camera features are disabled while running in offline mode due to memory constraints.',
      action: null
    });
  });

  socket.on('disconnect', () => {
    console.log('📱 Frontend disconnected:', socket.id);
    systemInfo.stopPolling();
  });
});

startBackend();

