const { app, BrowserWindow, ipcMain, screen, shell } = require('electron');
const path = require('path');
const activeWin = require('active-win');
const screenshot = require('screenshot-desktop');
const Tesseract = require('tesseract.js');
const fs = require('fs');
const os = require('os');

app.setAppUserModelId('com.jarvis.app');

const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  let mainWindow;
  let bubbleWindow;

  app.on('second-instance', (event, commandLine, workingDirectory) => {
    // Someone tried to run a second instance, we should focus our window.
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      if (!mainWindow.isVisible()) mainWindow.show();
      mainWindow.focus();
    }
  });

  // Require the existing backend server only in the primary instance
  require('./server.js');

  function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    title: 'JARVIS Dashboard',
    icon: path.join(__dirname, '../frontend/favicon.svg'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    autoHideMenuBar: true
  });

  // Load the backend server URL
  mainWindow.loadURL('http://localhost:3000');

  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    console.log(`[FRONTEND] ${message}`);
  });

  mainWindow.on('minimize', (event) => {
    event.preventDefault();
    mainWindow.hide();
    bubbleWindow.show();
  });

  mainWindow.on('close', (event) => {
    if (!app.isQuiting) {
      event.preventDefault();
      mainWindow.hide();
      bubbleWindow.show();
    }
    return false;
  });
}

function createBubbleWindow() {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;
  
  bubbleWindow = new BrowserWindow({
    width: 280,
    height: 260,
    x: width - 300,
    y: height - 280,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    resizable: false,
    skipTaskbar: true,
    show: false, // Initially hidden while dashboard is open
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  bubbleWindow.loadFile(path.join(__dirname, '../frontend/bubble.html'));

  // Allow clicking through transparent parts of the window if needed
  // bubbleWindow.setIgnoreMouseEvents(true, { forward: true });
}

// IPC handler to restore main window from the bubble
ipcMain.on('restore-dashboard', () => {
  bubbleWindow.hide();
  mainWindow.show();
  mainWindow.focus();
});

// IPC handler for bubble context-awareness (active window polling)
ipcMain.handle('get-active-window', async () => {
  try {
    const win = await activeWin();
    return win || null;
  } catch (err) {
    return null;
  }
});

// IPC handler to quit app completely
ipcMain.on('quit-app', () => {
  app.isQuiting = true;
  app.quit();
});

// Context Awareness API for the frontend
ipcMain.handle('get-system-context', async () => {
  try {
    const activeWindow = await activeWin();
    return activeWindow || null;
  } catch (err) {
    console.error('Failed to get active window:', err);
    return null;
  }
});

// Screen Capture & OCR API
ipcMain.handle('capture-and-read-screen', async () => {
  try {
    const tempFile = path.join(os.tmpdir(), `jarvis_screen_${Date.now()}.png`);
    await screenshot({ filename: tempFile });
    
    // OCR the screenshot
    const { data: { text } } = await Tesseract.recognize(tempFile, 'eng', {
      logger: m => console.log('OCR Progress:', m.status, m.progress)
    });
    
    // Clean up screenshot
    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
    
    return { success: true, text: text.trim() };
  } catch (err) {
    console.error('Screen capture/OCR failed:', err);
    return { success: false, error: err.message };
  }
});

app.whenReady().then(() => {
  if (process.platform === 'win32') {
    app.setAsDefaultProtocolClient('jarvis');
  }

  createMainWindow();
  createBubbleWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});
}
