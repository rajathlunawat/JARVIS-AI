const { io } = require('socket.io-client');
const socket = io('http://localhost:3000');

socket.on('connect', () => {
  console.log('Connected to server');
  socket.emit('command', { text: 'what is the time' });
});

socket.on('response', (res) => {
  console.log('Received response:', res);
  process.exit(0);
});

socket.on('connect_error', (err) => {
  console.log('Connection error:', err);
  process.exit(1);
});
