const io = require('socket.io-client');

const socket = io('http://localhost:3000');

const commands = [
  'open chrome',
  'search for weather in New York',
  'volume up',
  'screenshot',
  'what time is it'
];

socket.on('connect', () => {
  console.log('Connected to backend via WebSocket (dry-run)');

  let i = 0;
  const sendNext = () => {
    if (i >= commands.length) {
      console.log('All commands sent (dry-run).');
      socket.disconnect();
      return;
    }

    const text = commands[i++];
    console.log('\nSending:', text);
    socket.emit('command', { text, dryRun: true });

    // wait for response event
  };

  socket.on('response', (res) => {
    console.log('Response:', res);
    setTimeout(sendNext, 500);
  });

  sendNext();
});

socket.on('connect_error', (err) => {
  console.error('Connection error:', err.message);
});
