/**
 * ChatManager - Chat interface module for JARVIS Dashboard
 *
 * Renders user and Jarvis messages with timestamps, animations, and
 * optional action buttons. Jarvis messages use a word-by-word typing
 * reveal effect. Supports basic markdown-like formatting.
 *
 * @module chat
 */

'use strict';

class ChatManager {
  /**
   * @param {HTMLElement} containerEl - Scrollable chat message container
   * @param {HTMLInputElement} inputEl - Text input field
   * @param {HTMLButtonElement} sendBtnEl - Send button
   */
  constructor(containerEl, inputEl, sendBtnEl) {
    /** @type {HTMLElement} */
    this.container = containerEl;

    /** @type {HTMLInputElement} */
    this.input = inputEl;

    /** @type {HTMLButtonElement} */
    this.sendBtn = sendBtnEl;

    /**
     * External callback invoked when the user sends a command.
     * Set by the main app: `chatManager.onCommand = (text) => { ... }`
     * @type {function(string): void|null}
     */
    this.onCommand = null;

    /** @type {number} Auto-incrementing message ID */
    this._msgId = 0;

    // Bind UI events
    this._bindEvents();
  }

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /**
   * Add a message to the chat.
   *
   * @param {string} text - Message content (may include basic markdown)
   * @param {'user'|'jarvis'} sender - Who sent the message
   * @param {object} [options]
   * @param {string} [options.type] - Visual type hint (info|success|warning|error)
   * @param {Array<{label: string, action: function, style?: string}>} [options.actions]
   *   Buttons rendered at the bottom of the message
   * @returns {number} The message's unique ID
   */
  addMessage(text, sender = 'jarvis', options = {}) {
    const id = ++this._msgId;
    const bubble = this._createBubble(id, text, sender, options);

    this.container.appendChild(bubble);

    // Jarvis messages get a word-by-word typing reveal
    if (sender === 'jarvis') {
      this._revealWords(bubble, text, options);
    }

    this.scrollToBottom();
    return id;
  }

  /** Show a "Jarvis is typing…" indicator with animated dots. */
  addTypingIndicator() {
    this.removeTypingIndicator(); // Prevent duplicates

    const indicator = document.createElement('div');
    indicator.className = 'chat-message jarvis-message typing-indicator';
    indicator.id = 'typing-indicator';
    indicator.innerHTML = `
      <div class="message-avatar">
        <span class="avatar-icon">J</span>
      </div>
      <div class="message-content">
        <div class="typing-dots">
          <span class="dot"></span>
          <span class="dot"></span>
          <span class="dot"></span>
        </div>
      </div>
    `;

    this.container.appendChild(indicator);
    this.scrollToBottom();
  }

  /** Remove the typing indicator if present. */
  removeTypingIndicator() {
    const el = document.getElementById('typing-indicator');
    if (el) {
      el.remove();
    }
  }

  /** Smoothly scroll the chat container to the bottom. */
  scrollToBottom() {
    requestAnimationFrame(() => {
      this.container.scrollTo({
        top: this.container.scrollHeight,
        behavior: 'smooth',
      });
    });
  }

  /** Clear all messages from the chat container. */
  clearChat() {
    this.container.innerHTML = '';
    this._msgId = 0;
  }

  /**
   * Apply basic markdown-like formatting to text.
   *   **bold**  →  <strong>
   *   `code`   →  <code>
   *   [text](url) → <a>
   *   \n       →  <br>
   *
   * @param {string} text
   * @returns {string} HTML string
   */
  formatMessage(text) {
    if (!text) return '';

    let html = this._escapeHTML(text);

    // Bold: **text**
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

    // Inline code: `code`
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Links: [text](url)
    html = html.replace(
      /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'
    );

    // Line breaks
    html = html.replace(/\n/g, '<br>');

    return html;
  }

  /** Read input, clear it, and fire the onCommand callback. */
  handleSend() {
    const text = this.input.value.trim();
    if (!text) return;

    // Show user message immediately
    this.addMessage(text, 'user');
    this.input.value = '';
    this.input.focus();

    // Notify the app controller
    if (typeof this.onCommand === 'function') {
      this.onCommand(text);
    }
  }

  // ---------------------------------------------------------------------------
  // Private — DOM construction
  // ---------------------------------------------------------------------------

  /**
   * Create the full message bubble DOM element.
   * @returns {HTMLElement}
   */
  _createBubble(id, text, sender, options) {
    const wrapper = document.createElement('div');
    wrapper.className = `chat-message ${sender}-message fadeInUp`;
    wrapper.dataset.msgId = id;

    if (options.type) {
      wrapper.classList.add(`msg-${options.type}`);
    }

    const isJarvis = sender === 'jarvis';
    const avatarLetter = isJarvis ? 'J' : 'U';
    const formattedText = this.formatMessage(text);
    const timestamp = this._timestamp();

    wrapper.innerHTML = `
      <div class="message-avatar">
        <span class="avatar-icon">${avatarLetter}</span>
      </div>
      <div class="message-content">
        <div class="message-text">${isJarvis ? '' : formattedText}</div>
        <div class="message-meta">
          <span class="message-time">${timestamp}</span>
        </div>
      </div>
    `;

    // Append action buttons if provided
    if (options.actions && options.actions.length > 0) {
      const actionsContainer = document.createElement('div');
      actionsContainer.className = 'message-actions';

      options.actions.forEach((actionDef) => {
        const btn = document.createElement('button');
        btn.className = `action-btn ${actionDef.style || ''}`;
        btn.textContent = actionDef.label;
        btn.addEventListener('click', () => {
          if (typeof actionDef.action === 'function') {
            actionDef.action();
          }
          // Disable after click to prevent double-fire
          btn.disabled = true;
          btn.classList.add('action-used');
        });
        actionsContainer.appendChild(btn);
      });

      // Insert after .message-content
      const content = wrapper.querySelector('.message-content');
      content.appendChild(actionsContainer);
    }

    return wrapper;
  }

  /**
   * Reveal a Jarvis message word by word with a slight delay.
   * @param {HTMLElement} bubble - The message bubble element
   * @param {string} text - Raw text to reveal
   * @param {object} options
   */
  _revealWords(bubble, text, options) {
    const textEl = bubble.querySelector('.message-text');
    if (!textEl) return;

    const words = text.split(/\s+/);
    const WORD_DELAY = 40; // ms between words
    let currentIndex = 0;
    let accumulated = '';

    const revealNext = () => {
      if (currentIndex >= words.length) {
        // Final pass — apply markdown formatting once complete
        textEl.innerHTML = this.formatMessage(text);
        this.scrollToBottom();
        return;
      }

      accumulated += (currentIndex > 0 ? ' ' : '') + words[currentIndex];
      textEl.textContent = accumulated;
      currentIndex++;
      this.scrollToBottom();
      setTimeout(revealNext, WORD_DELAY);
    };

    revealNext();
  }

  // ---------------------------------------------------------------------------
  // Private — Events
  // ---------------------------------------------------------------------------

  /** Bind send button click and Enter key. */
  _bindEvents() {
    if (this.sendBtn) {
      this.sendBtn.addEventListener('click', () => this.handleSend());
    }

    if (this.input) {
      this.input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.handleSend();
        }
      });
    }
  }

  // ---------------------------------------------------------------------------
  // Private — Utilities
  // ---------------------------------------------------------------------------

  /**
   * Generate a human-readable timestamp string.
   * @returns {string} e.g. "5:06 PM"
   */
  _timestamp() {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }

  /**
   * Escape HTML special characters to prevent XSS.
   * @param {string} str
   * @returns {string}
   */
  _escapeHTML(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }
}

// Expose globally (no bundler)
window.ChatManager = ChatManager;
