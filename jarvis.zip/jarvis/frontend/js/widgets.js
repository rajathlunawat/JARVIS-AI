/**
 * SystemWidgets - System monitoring widgets module for JARVIS Dashboard
 *
 * Displays CPU, RAM, Battery, and Disk usage with animated progress bars.
 * In demo mode, values are simulated with realistic ranges.
 * Designed to be replaced with real WebSocket data when backend is connected.
 *
 * @module widgets
 */

'use strict';

class SystemWidgets {
  /**
   * @param {HTMLElement} containerEl - Parent container holding all widget elements
   */
  constructor(containerEl) {
    /** @type {HTMLElement} */
    this.container = containerEl;

    /** @type {number|null} Interval ID for simulation loop */
    this._simulationInterval = null;

    /** @type {boolean} Whether simulation is currently running */
    this._running = false;

    // --- Current simulated values ---
    /** @type {number} */
    this._cpu = 30;
    /** @type {number} */
    this._ram = 52;
    /** @type {number} */
    this._battery = 100;
    /** @type {boolean} */
    this._charging = false;
    /** @type {number} */
    this._disk = 55;

    // Cache DOM references for each widget
    this._elements = {
      cpu: {
        bar: document.getElementById('cpu-bar'),
        label: document.getElementById('cpu-label'),
      },
      ram: {
        bar: document.getElementById('ram-bar'),
        label: document.getElementById('ram-label'),
      },
      battery: {
        bar: document.getElementById('battery-bar'),
        label: document.getElementById('battery-label'),
        icon: document.getElementById('battery-icon'),
      },
      disk: {
        bar: document.getElementById('disk-bar'),
        label: document.getElementById('disk-label'),
      },
    };
  }

  // ---------------------------------------------------------------------------
  // Public API — called by app.js or future WebSocket handler
  // ---------------------------------------------------------------------------

  /**
   * Update the CPU usage widget.
   * @param {number} percent - CPU usage 0-100
   */
  updateCPU(percent) {
    const value = this._clamp(percent);
    this._cpu = value;
    this._setBar('cpu', value);
    this._setLabel('cpu', `${Math.round(value)}%`);
    this._colorize('cpu', value);
  }

  /**
   * Update the RAM usage widget.
   * @param {number} percent - RAM usage 0-100
   */
  updateRAM(percent) {
    const value = this._clamp(percent);
    this._ram = value;
    this._setBar('ram', value);
    this._setLabel('ram', `${Math.round(value)}%`);
    this._colorize('ram', value);
  }

  /**
   * Update the Battery widget.
   * @param {number} percent  - Battery level 0-100
   * @param {boolean} charging - Whether the device is plugged in
   */
  updateBattery(percent, charging = false) {
    const value = this._clamp(percent);
    this._battery = value;
    this._charging = charging;
    this._setBar('battery', value);

    const chargingText = charging ? ' ⚡' : '';
    this._setLabel('battery', `${Math.round(value)}%${chargingText}`);

    // Colour thresholds specific to battery (invert logic — low is bad)
    const el = this._elements.battery;
    if (el.bar) {
      el.bar.classList.remove('bar-normal', 'bar-warning', 'bar-critical');
      if (value <= 15) {
        el.bar.classList.add('bar-critical');
      } else if (value <= 30) {
        el.bar.classList.add('bar-warning');
      } else {
        el.bar.classList.add('bar-normal');
      }
    }

    // Update charging icon visibility
    if (el.icon) {
      el.icon.style.display = charging ? 'inline' : 'none';
    }
  }

  /**
   * Update the Disk usage widget.
   * @param {number} percent - Disk usage 0-100
   */
  updateDisk(percent) {
    const value = this._clamp(percent);
    this._disk = value;
    this._setBar('disk', value);
    this._setLabel('disk', `${Math.round(value)}%`);
    this._colorize('disk', value);
  }

  // ---------------------------------------------------------------------------
  // Simulation — generates realistic demo data until real backend is connected
  // ---------------------------------------------------------------------------

  /**
   * Start simulating slowly-changing system metrics.
   * CPU:     15–85 %, fluctuates each tick
   * RAM:     40–75 %, drifts slowly
   * Battery: decreases from 100 % at ~0.3 % per tick
   * Disk:    45–65 %, mostly static with tiny drift
   */
  startSimulation() {
    if (this._running) return;
    this._running = true;

    // Seed initial values
    this.updateCPU(this._cpu);
    this.updateRAM(this._ram);
    this.updateBattery(this._battery, this._charging);
    this.updateDisk(this._disk);

    this._simulationInterval = setInterval(() => this._tick(), 2000);
  }

  /** Stop the simulation loop. */
  stopSimulation() {
    this._running = false;
    if (this._simulationInterval !== null) {
      clearInterval(this._simulationInterval);
      this._simulationInterval = null;
    }
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  /** One simulation tick — update each metric realistically. */
  _tick() {
    // CPU: fluctuates ±5 within 15–85
    this._cpu = this._drift(this._cpu, 5, 15, 85);
    this.updateCPU(this._cpu);

    // RAM: drifts slowly ±2 within 40–75
    this._ram = this._drift(this._ram, 2, 40, 75);
    this.updateRAM(this._ram);

    // Battery: drains ~0.3 % per tick, wraps back to 100 when hitting 5
    this._battery -= 0.3 + Math.random() * 0.2;
    if (this._battery <= 5) {
      this._battery = 100;
      this._charging = true;
    }
    if (this._battery >= 95) {
      this._charging = false;
    }
    this.updateBattery(this._battery, this._charging);

    // Disk: mostly static, tiny ±0.5 within 45–65
    this._disk = this._drift(this._disk, 0.5, 45, 65);
    this.updateDisk(this._disk);
  }

  /**
   * Drift a value randomly within a range.
   * @param {number} current - Current value
   * @param {number} maxDelta - Maximum change per tick
   * @param {number} min - Floor
   * @param {number} max - Ceiling
   * @returns {number}
   */
  _drift(current, maxDelta, min, max) {
    const delta = (Math.random() - 0.5) * 2 * maxDelta;
    return this._clamp(current + delta, min, max);
  }

  /**
   * Clamp a number between min and max.
   * @param {number} value
   * @param {number} [min=0]
   * @param {number} [max=100]
   * @returns {number}
   */
  _clamp(value, min = 0, max = 100) {
    return Math.min(max, Math.max(min, value));
  }

  /**
   * Set a progress bar width.
   * @param {string} key - Widget key (cpu|ram|battery|disk)
   * @param {number} percent
   */
  _setBar(key, percent) {
    const bar = this._elements[key]?.bar;
    if (bar) {
      bar.style.width = `${percent}%`;
    }
  }

  /**
   * Set a label's text content.
   * @param {string} key
   * @param {string} text
   */
  _setLabel(key, text) {
    const label = this._elements[key]?.label;
    if (label) {
      label.textContent = text;
    }
  }

  /**
   * Apply colour class based on usage thresholds.
   * Normal: < 60 %, Warning: 60–80 %, Critical: > 80 %
   * @param {string} key
   * @param {number} value
   */
  _colorize(key, value) {
    const bar = this._elements[key]?.bar;
    if (!bar) return;

    bar.classList.remove('bar-normal', 'bar-warning', 'bar-critical');
    if (value >= 80) {
      bar.classList.add('bar-critical');
    } else if (value >= 60) {
      bar.classList.add('bar-warning');
    } else {
      bar.classList.add('bar-normal');
    }
  }
}

// Expose globally (no bundler)
window.SystemWidgets = SystemWidgets;
