/**
 * Main application controller for JARVIS minimalist UI
 */
'use strict';

class JarvisApp {
  constructor() {
    this.socket = io('http://localhost:3000');
    this.voice = null;
    this.camera = null;
    this.notificationId = 0;
    this.language = 'en';
    this._strings = this._getStrings();

    // UI Elements
    this.blobEl = document.getElementById('jarvisBlob');
    this.subtitleEl = document.getElementById('jarvisSubtitle');
    this.micBtn = document.getElementById('micBtn');
    this.uploadBtn = document.getElementById('uploadBtn');
    this.langToggleBtn = document.getElementById('langToggleBtn');
    this.fileInput = document.getElementById('fileInput');
    this.chatMessages = document.getElementById('chatMessages');
    this.commandHistory = document.getElementById('commandHistory');
    this.textInput = document.getElementById('textInput');
    this.sendTextBtn = document.getElementById('sendTextBtn');

    // Audio Context for voice blob reactivity
    this.audioCtx = null;
    this.analyser = null;
    this.dataArray = null;
    this.source = null;
    this.animationFrame = null;
  }

  init() {
    // ---- Voice Engine ----
    this.voice = new VoiceEngine();
    this.chatHistoryData = [];
    this.historyStorageKey = 'jarvisChatHistory';
    
    this.voice.onResult((transcript) => {
      if (this.textInput) this.textInput.value = transcript;
      this.handleCommand(transcript);
    });

    this.voice.onStateChange((state) => {
      if (state === 'listening') {
        this.micBtn.classList.add('listening');
        if (this.textInput) this.textInput.placeholder = this._strings.placeholder.listening;
        this.startAudioAnalysis();
      } else if (state === 'speaking') {
        if (this.blobEl) this.blobEl.style.animation = "pulse 1s infinite alternate";
      } else if (state === 'speech-end') {
        if (this.blobEl) this.blobEl.style.animation = "none";
        this.subtitleEl.textContent = this._strings.subtitles.welcome;
        if (this.textInput) this.textInput.placeholder = this._strings.placeholder.command;
      } else {
        this.micBtn.classList.remove('listening');
        if (state === 'stopped') this.stopAudioAnalysis();
      }
    });

    if (this.micBtn) {
      this.micBtn.addEventListener('click', () => {
        console.log("Mic button clicked!");
        if (this.voice.listening) {
          this.voice.stopListening();
          if (this.textInput) this.textInput.placeholder = this._strings.placeholder.command;
        } else {
          this.voice.startListening();
        }
      });
    }

    if (this.langToggleBtn) {
      this.langToggleBtn.addEventListener('click', () => {
        this.language = this.language === 'en' ? 'hi' : 'en';
        this.translateUI();
        this.wishMe();
      });
    }

    // ---- Text Input ----
    const submitText = () => {
      const text = this.textInput.value.trim();
      console.log("Submit text called with:", text);
      if (text) {
        this.handleCommand(text);
        this.textInput.value = '';
      }
    };

    if (this.sendTextBtn && this.textInput) {
      this.sendTextBtn.addEventListener('click', () => {
        console.log("Send text button clicked!");
        submitText();
      });
      this.textInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') submitText();
      });
    }

    // ---- File Upload Engine ----
    if (this.uploadBtn && this.fileInput) {
      this.uploadBtn.addEventListener('click', () => {
        this.fileInput.click();
      });

      this.fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        this.subtitleEl.textContent = `Reading ${file.name}...`;
        const formData = new FormData();
        formData.append('file', file);

        try {
          const res = await fetch('http://localhost:3000/api/upload', {
            method: 'POST',
            body: formData
          });
          const data = await res.json();
          if (data.success) {
            this.currentFileContext = {
              filename: data.filename,
              text: data.text,
              scanPath: data.scanPath || null
            };
            this.showNotification(this._strings.notifications.fileLoadSuccess.replace('{fileName}', file.name), 'success');
            this.subtitleEl.textContent = this._strings.subtitles.analyzingFile.replace('{fileName}', file.name);
            
            // Automatically trigger analysis
            this.handleCommand(this.language === 'hi' ? 'इस फ़ाइल का सारांश दें।' : 'Analyze this file and give me a brief summary of its contents.');
          } else {
            this.showNotification(data.error || this._strings.notifications.fileLoadError, 'error');
            this.subtitleEl.textContent = this._strings.subtitles.fileFailed;
          }
        } catch (err) {
          console.error("Upload error:", err);
          this.showNotification('Error connecting to backend.', 'error');
        }
        
        // Reset input so the same file can be uploaded again if needed
        this.fileInput.value = '';
      });
    }

    // ---- Liquid Navigation ----
    this.initNavigation();

    // ---- Socket Events ----
    this.socket.on('connect', () => {
      console.log('Connected to backend server');
      this.showNotification(this._strings.notifications.online, 'success');
    });

    this.socket.on('response', (res) => {
      // Show explicit notification for reminders
      if (res.type === 'reminder') {
        this.showNotification('⏰ ' + res.text, 'success', 10000);
      }

      // Update subtitle
      this.subtitleEl.textContent = res.text ? res.text.substring(0, 80) + '...' : this._strings.subtitles.taskCompleted;
      
      // Update chat view
      const responseText = res.text || '';
      this.addChatMessage(responseText, 'jarvis', res);
      if (responseText) {
        const jarvisEntry = { sender: 'jarvis', text: responseText, timestamp: new Date().toISOString() };
        this.saveChatHistoryEntry(jarvisEntry);
        this.addToHistory(jarvisEntry);
      }

      // Speak response
      if (responseText) {
        this.speakWithBlobSync(responseText.replace(/[😊📸🔇🔊🔉⚠️⏰]/g, ''));
      }
    });

    // ---- Restore saved history and initial greeting ----
    this.loadSavedHistory();
    this.translateUI();
    this.wishMe();
  }

  wishMe() {
    const hour = new Date().getHours();
    const isHindi = this.language === 'hi';
    const greetings = isHindi ? [
      'सुप्रभात! JARVIS तैयार है, बताइए क्या करना है?',
      'आप वापस आ गए हैं। बताइए अब क्या करना है?',
      'नमस्ते। मैं सहायता के लिए तैयार हूँ।',
      'JARVIS सक्रिय है। अब बताएं क्या चाहिए?',
      'कैसे मदद कर सकता हूँ?'
    ] : [
      'Good morning. JARVIS is ready. How can I assist you?',
      'Welcome back. What would you like to do today?',
      'JARVIS is online and ready to help.',
      'Please tell me what to do next.',
      'Ready when you are. How can I assist?'
    ];

    const storageKey = this.language === 'hi' ? 'jarvisLastHindiGreeting' : 'jarvisLastEnglishGreeting';
    const lastIndex = parseInt(localStorage.getItem(storageKey), 10);
    let nextIndex = Math.floor(Math.random() * greetings.length);
    if (!Number.isNaN(lastIndex) && greetings.length > 1) {
      while (nextIndex === lastIndex) {
        nextIndex = Math.floor(Math.random() * greetings.length);
      }
    }
    localStorage.setItem(storageKey, nextIndex.toString());

    const greeting = greetings[nextIndex];
    this.subtitleEl.textContent = greeting;
    this.speakWithBlobSync(greeting);
  }

  _getStrings() {
    return {
      en: {
        placeholder: {
          command: 'Type a command or click mic...',
          listening: 'Listening...'
        },
        subtitles: {
          welcome: 'I am Virtual Assistant JARVIS, How may I help you?',
          readingFile: 'Reading {fileName}...',
          analyzingFile: 'Analyzing {fileName}...',
          fileFailed: 'Failed to load file.',
          processing: 'Processing...',
          taskCompleted: 'Task completed.'
        },
        notifications: {
          online: 'JARVIS Online',
          fileLoadSuccess: 'Loaded {fileName}',
          fileLoadError: 'Failed to read file',
          backendOffline: 'Error connecting to backend.',
          disconnected: 'Cannot process command, server disconnected.'
        }
      },
      hi: {
        placeholder: {
          command: 'कमांड टाइप करें या माइक्रोफ़ोन दबाएं...',
          listening: 'सुन रहा हूँ...'
        },
        subtitles: {
          welcome: 'मैं वर्चुअल असिस्टेंट JARVIS हूँ, कैसे मदद करूँ?',
          readingFile: '{fileName} पढ़ रहा हूँ...',
          analyzingFile: '{fileName} का विश्लेषण कर रहा हूँ...',
          fileFailed: 'फ़ाइल लोड करने में विफल।',
          processing: 'प्रोसेस कर रहा हूँ...',
          taskCompleted: 'कार्य पूर्ण हुआ।'
        },
        notifications: {
          online: 'JARVIS ऑनलाइन है',
          fileLoadSuccess: '{fileName} लोड हो गया',
          fileLoadError: 'फ़ाइल पढ़ने में विफल',
          backendOffline: 'बैकएंड से कनेक्ट करने में त्रुटि।',
          disconnected: 'कमांड प्रोसेस नहीं कर सकता, सर्वर डिस्कनेक्टेड है।'
        }
      }
    };
  }

  translateUI() {
    this._strings = this._getStrings()[this.language];
    if (this.textInput) this.textInput.placeholder = this._strings.placeholder.command;
    if (this.langToggleBtn) {
      this.langToggleBtn.textContent = this.language === 'en' ? 'HI' : 'EN';
      this.langToggleBtn.title = this.language === 'en' ? 'Switch to Hindi' : 'Switch to English';
    }
    const navTextMap = {
      en: ['Home', 'Chat', 'History'],
      hi: ['होम', 'चैट', 'इतिहास']
    };
    document.querySelectorAll('.liquid-nav ul li a .nav-text').forEach((el, idx) => {
      el.textContent = navTextMap[this.language][idx] || el.textContent;
    });
  }

  handleCommand(text) {
    if (!text) return;
    const userEntry = {
      sender: 'user',
      text,
      timestamp: new Date().toISOString()
    };

    this.addChatMessage(text, 'user');
    this.saveChatHistoryEntry(userEntry);
    this.addToHistory(userEntry);

    // Command routing
    if (this.socket.connected) {
      const fileCtx = this.currentFileContext || null;
      this.socket.emit('command', {
        text,
        fileContext: fileCtx,
        chatHistory: this.chatHistoryData.slice(-16)
      });
      // Clear file context after sending so it doesn't persist for future commands
      if (fileCtx) {
        this.currentFileContext = null;
      }
      this.subtitleEl.textContent = this._strings.subtitles.processing;
    } else {
      this.showNotification(this._strings.notifications.disconnected, 'error');
    }
  }

  addChatMessage(text, sender, meta = null) {
    if (!this.chatMessages || !text) return;
    
    const div = document.createElement('div');
    div.className = `message ${sender}`;
    
    let content = text;
    // Format vision data if present
    if (meta && meta.type === 'vision_success' && meta.visionData) {
      content = `<strong>${meta.visionData.object}</strong><br><br>${meta.visionData.description}<br><br><em>Where to buy:</em><br>${meta.visionData.buyingGuide}`;
    }

    div.innerHTML = `<div class="bubble">${content}</div>`;
    this.chatMessages.appendChild(div);
    this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
  }

  addToHistory(entry) {
    if (!this.commandHistory || !entry) return;
    
    // Remove "No recent commands" text if present
    const emptyMsg = this.commandHistory.querySelector('p');
    if (emptyMsg) emptyMsg.remove();

    const time = new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const label = entry.sender === 'user' ? 'You' : 'JARVIS';
    const div = document.createElement('div');
    div.style.padding = '10px';
    div.style.borderBottom = '1px solid rgba(255,255,255,0.1)';
    div.innerHTML = `<strong style="color:var(--accent)">[${time}]</strong> <em>${label}</em>: ${entry.text}`;
    
    this.commandHistory.prepend(div);
  }

  saveChatHistoryEntry(entry) {
    if (!entry || !entry.text) return;
    this.chatHistoryData.push(entry);
    try {
      localStorage.setItem(this.historyStorageKey, JSON.stringify(this.chatHistoryData));
    } catch (err) {
      console.warn('Could not persist chat history:', err);
    }
  }

  loadSavedHistory() {
    if (!window.localStorage) return;
    const raw = localStorage.getItem(this.historyStorageKey);
    if (!raw) return;

    try {
      const saved = JSON.parse(raw);
      if (!Array.isArray(saved)) return;
      this.chatHistoryData = saved;

      this.chatHistoryData.forEach((entry) => {
        this.addChatMessage(entry.text, entry.sender);
      });

      this.renderHistoryList();
    } catch (err) {
      console.warn('Failed to load saved chat history:', err);
      this.chatHistoryData = [];
    }
  }

  renderHistoryList() {
    if (!this.commandHistory) return;

    this.commandHistory.innerHTML = '';
    if (!this.chatHistoryData.length) {
      this.commandHistory.innerHTML = '<p style="color: #666; text-align: center; margin-top: 20px;">No recent commands.</p>';
      return;
    }

    this.chatHistoryData.slice().reverse().forEach((entry) => {
      const time = new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const label = entry.sender === 'user' ? 'You' : 'JARVIS';
      const div = document.createElement('div');
      div.style.padding = '10px';
      div.style.borderBottom = '1px solid rgba(255,255,255,0.1)';
      div.innerHTML = `<strong style="color:var(--accent)">[${time}]</strong> <em>${label}</em>: ${entry.text}`;
      this.commandHistory.appendChild(div);
    });
  }

  initNavigation() {
    const list = document.querySelectorAll('.liquid-nav li');
    const views = document.querySelectorAll('.view-container');

    list.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Update Nav UI
        list.forEach(li => li.classList.remove('active'));
        item.classList.add('active');

        // Update Views
        const targetId = item.getAttribute('data-target');
        views.forEach(view => {
          view.classList.remove('active-view');
          if (view.id === targetId) {
            view.classList.add('active-view');
          }
        });
      });
    });
  }

  // --- Voice Reactive Blob Logic ---

  async startAudioAnalysis() {
    try {
      if (!this.audioCtx) {
        this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        this.analyser = this.audioCtx.createAnalyser();
        this.analyser.fftSize = 256;
        this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
      }

      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }

      if (!this.source) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        this.source = this.audioCtx.createMediaStreamSource(stream);
        this.source.connect(this.analyser);
      }

      const drawPulse = () => {
        this.animationFrame = requestAnimationFrame(drawPulse);
        this.analyser.getByteFrequencyData(this.dataArray);
        
        // Calculate average volume
        let sum = 0;
        for (let i = 0; i < this.dataArray.length; i++) {
          sum += this.dataArray[i];
        }
        const average = sum / this.dataArray.length;
        
        // Scale blob between 1.0 and 1.2
        const scale = 1 + (average / 255) * 0.2;
        if (this.blobEl) {
          this.blobEl.style.transform = `scale(${scale})`;
        }
      };

      drawPulse();
    } catch (err) {
      console.warn("Audio analysis failed:", err);
    }
  }

  stopAudioAnalysis() {
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }
    if (this.blobEl) {
      this.blobEl.style.transform = `scale(1)`;
    }
  }

  speakWithBlobSync(text) {
    if (!this.voice) return;
    
    // We rely on VoiceEngine's internal chunking and events.
    // It will emit 'speaking' and 'speech-end' which we handle in onStateChange.
    this.voice.speak(text).catch(err => console.warn("TTS Error:", err));
  }

  showNotification(message, type = 'info', duration = 3000) {
    const container = document.getElementById('notificationContainer');
    if (!container) return;
    const id = `notif-${++this.notificationId}`;
    const el = document.createElement('div');
    el.className = `notification ${type}`;
    el.id = id;
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    if (type === 'error') icon = 'times-circle';
    el.innerHTML = `
      <i class="fas fa-${icon}"></i>
      <span class="notif-text">${message}</span>
      <button class="notif-close" onclick="document.getElementById('${id}').remove()"><i class="fas fa-times"></i></button>
    `;
    container.appendChild(el);
    setTimeout(() => {
      const target = document.getElementById(id);
      if (target) {
        target.classList.add('fadeOutRight');
        setTimeout(() => target.remove(), 300);
      }
    }, duration);
  }
}

// Initialize on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  window.jarvis = new JarvisApp();
  window.jarvis.init();
});
