/**
 * CameraEngine — Camera capture module for JARVIS Dashboard
 *
 * Uses navigator.mediaDevices.getUserMedia to access the device camera,
 * renders a live preview, captures frames to base64 JPEG, and sends
 * them to the backend for Gemini multimodal vision analysis.
 *
 * @module camera
 */

'use strict';

class CameraEngine {
  constructor() {
    /** @type {MediaStream|null} Active camera stream */
    this._stream = null;

    /** @type {HTMLVideoElement|null} Live preview element */
    this._videoEl = null;

    /** @type {HTMLCanvasElement} Off-screen canvas for frame capture */
    this._canvas = document.createElement('canvas');

    /** @type {boolean} Whether camera is currently active */
    this._active = false;

    /** @type {boolean} Whether browser supports getUserMedia */
    this._supported = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);

    /** @type {Function|null} Callback invoked with captured image base64 */
    this._onCaptureCallback = null;
  }

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /**
   * Check whether the browser supports camera access.
   * @returns {boolean}
   */
  isSupported() {
    return this._supported;
  }

  /** @returns {boolean} Whether camera is currently streaming */
  get active() {
    return this._active;
  }

  /**
   * Register a callback for when a frame is captured.
   * @param {function(string): void} callback - Receives base64 JPEG string
   */
  onCapture(callback) {
    if (typeof callback === 'function') {
      this._onCaptureCallback = callback;
    }
  }

  /**
   * Open the camera and start live preview.
   * @returns {Promise<void>}
   */
  async open() {
    if (!this._supported) {
      this._notify('Camera is not supported in this browser.', 'error');
      return;
    }

    if (this._active) return;

    try {
      // Request camera access — prefer rear camera on mobile, any on desktop
      this._stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });

      // Attach stream to video element
      this._videoEl = document.getElementById('cameraPreview');
      if (this._videoEl) {
        this._videoEl.srcObject = this._stream;
        this._videoEl.play();
      }

      this._active = true;
      this._showOverlay(true);
      this._notify('Camera activated.', 'info', 2000);

    } catch (err) {
      console.error('[CameraEngine] Failed to open camera:', err);

      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        this._notify('Camera permission denied. Please allow camera access.', 'error');
      } else if (err.name === 'NotFoundError') {
        this._notify('No camera found on this device.', 'error');
      } else if (err.name === 'NotReadableError') {
        this._notify('Camera is already in use by another application.', 'warning');
      } else {
        this._notify(`Camera error: ${err.message}`, 'error');
      }
    }
  }

  /**
   * Capture a single frame from the live video feed.
   * @param {string} [userPrompt] - Optional text prompt to send with the image
   * @returns {string|null} Base64 JPEG string, or null on failure
   */
  capture(userPrompt = '') {
    if (!this._active || !this._videoEl) {
      this._notify('Camera is not active.', 'warning');
      return null;
    }

    // Match canvas dimensions to the actual video feed
    const vw = this._videoEl.videoWidth;
    const vh = this._videoEl.videoHeight;
    this._canvas.width = vw;
    this._canvas.height = vh;

    const ctx = this._canvas.getContext('2d');
    ctx.drawImage(this._videoEl, 0, 0, vw, vh);

    // Convert to base64 JPEG (0.85 quality for balance of size vs quality)
    const base64 = this._canvas.toDataURL('image/jpeg', 0.85);

    // Strip the data URL prefix to get raw base64
    const rawBase64 = base64.replace(/^data:image\/jpeg;base64,/, '');

    // Flash effect on the overlay
    this._flashEffect();

    // Emit to callback
    if (this._onCaptureCallback) {
      this._onCaptureCallback(rawBase64, userPrompt);
    }

    return rawBase64;
  }

  /**
   * Stop the camera and close the overlay.
   */
  close() {
    if (this._stream) {
      this._stream.getTracks().forEach(track => track.stop());
      this._stream = null;
    }

    if (this._videoEl) {
      this._videoEl.srcObject = null;
    }

    this._active = false;
    this._showOverlay(false);
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  /**
   * Toggle the camera overlay visibility.
   * @param {boolean} show
   */
  _showOverlay(show) {
    const overlay = document.getElementById('cameraOverlay');
    if (overlay) {
      if (show) {
        overlay.classList.add('is-active');
      } else {
        overlay.classList.remove('is-active');
      }
    }
  }

  /**
   * Flash effect when a photo is captured.
   */
  _flashEffect() {
    const flash = document.getElementById('cameraFlash');
    if (flash) {
      flash.classList.add('flash-active');
      setTimeout(() => flash.classList.remove('flash-active'), 300);
    }
  }

  /**
   * Show a notification via the global JarvisApp instance.
   * @param {string} message
   * @param {string} type
   * @param {number} [duration]
   */
  _notify(message, type = 'info', duration) {
    if (window.jarvis && typeof window.jarvis.showNotification === 'function') {
      window.jarvis.showNotification(message, type, duration);
    } else {
      console.warn(`[CameraEngine] ${type}: ${message}`);
    }
  }
}

// Expose globally
window.CameraEngine = CameraEngine;
