/**
 * VoiceEngine - Voice recognition & text-to-speech module for JARVIS Dashboard
 *
 * Uses the Web Speech API (SpeechRecognition) for speech-to-text and
 * SpeechSynthesis for text-to-speech. Handles browser support detection,
 * microphone permission errors, and network failures gracefully.
 *
 * @module voice
 */

'use strict';

class VoiceEngine {
  constructor() {
    // --- Speech Recognition setup ---
    /** @type {SpeechRecognition|null} */
    this._recognition = null;

    /** @type {boolean} */
    this._listening = false;

    /** @type {boolean} Whether the browser supports SpeechRecognition */
    this._supported = false;

    /** @type {Function|null} Callback invoked with final recognised text */
    this._onResultCallback = null;

    /** @type {Function|null} Callback invoked on state changes (listening|stopped|error) */
    this._onStateChangeCallback = null;

    // --- Speech Synthesis setup ---
    /** @type {SpeechSynthesisVoice|null} Selected TTS voice */
    this._selectedVoice = null;

    /** @type {SpeechSynthesisVoice[]} Cached voice list */
    this._voices = [];

    // Detect support and initialise
    this._initRecognition();
    this._initSynthesis();
  }

  // ---------------------------------------------------------------------------
  // Public API — Speech Recognition
  // ---------------------------------------------------------------------------

  /**
   * Check whether the browser supports the Web Speech API.
   * @returns {boolean}
   */
  isSupported() {
    return this._supported;
  }

  /** Initialise SpeechRecognition with event handlers and edge-case guards. */
  _initRecognition() {
    this._supported = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.AudioContext);
    
    if (!this._supported) {
      console.info('[VoiceEngine] Web Audio API not available. Offline STT will not work.');
      return;
    }

    // Connect to backend socket for STT results when socket is ready
    const checkSocket = setInterval(() => {
      if (window.jarvis && window.jarvis.socket) {
        clearInterval(checkSocket);
        window.jarvis.socket.on('transcribe_result', (text) => {
          if (text && this._onResultCallback) {
            this._onResultCallback(text);
          }
        });
        window.jarvis.socket.on('transcribe_error', (err) => {
          this._notify(`Offline STT Error: ${err}`, 'error');
          this.stopListening();
        });
      }
    }, 500);
  }

  async startListening() {
    if (!this._supported) {
      this._emitState('error');
      this._notify('Audio recording is not supported in this browser.', 'error');
      return;
    }

    if (this._listening) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this._listening = true;
      this._toggleMicAnimation(true);
      this._emitState('listening');

      this.audioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
      this.mediaStreamSource = this.audioContext.createMediaStreamSource(stream);
      this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
      
      this.audioBuffer = [];
      this.stream = stream;

      this.processor.onaudioprocess = (e) => {
        if (!this._listening) return;
        const channelData = e.inputBuffer.getChannelData(0);
        this.audioBuffer.push(new Float32Array(channelData));
      };

      this.mediaStreamSource.connect(this.processor);
      this.processor.connect(this.audioContext.destination);
    } catch (err) {
      console.error('[VoiceEngine] Mic error:', err);
      this._notify('Microphone access denied or error occurred.', 'error');
      this._emitState('error');
    }
  }

  stopListening() {
    if (!this._listening) return;

    this._listening = false;
    this._toggleMicAnimation(false);
    this._emitState('stopped');

    if (this.processor) {
      this.processor.disconnect();
      this.mediaStreamSource.disconnect();
      this.processor = null;
      this.mediaStreamSource = null;
    }
    
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }

    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }

    // Flatten audio buffer
    if (this.audioBuffer && this.audioBuffer.length > 0) {
      const length = this.audioBuffer.reduce((acc, curr) => acc + curr.length, 0);
      const flattened = new Float32Array(length);
      let offset = 0;
      this.audioBuffer.forEach(buffer => {
        flattened.set(buffer, offset);
        offset += buffer.length;
      });

      // Send to backend
      if (window.jarvis && window.jarvis.socket) {
        window.jarvis.socket.emit('transcribe_audio', flattened.buffer);
      }
      this.audioBuffer = [];
    }
  }

  // ---------------------------------------------------------------------------
  // Public API — Events & Getters
  // ---------------------------------------------------------------------------

  get listening() {
    return this._listening;
  }

  onResult(callback) {
    this._onResultCallback = callback;
  }

  onStateChange(callback) {
    this._onStateChangeCallback = callback;
  }

  /** Load available TTS voices (they may arrive asynchronously). */
  _initSynthesis() {
    if (!window.speechSynthesis) return;

    const loadVoices = () => {
      this._voices = window.speechSynthesis.getVoices();

      // Try to pick a good default English or Hindi voice
      if (!this._selectedVoice && this._voices.length > 0) {
        const preferred = this._voices.find(
          (v) =>
            v.lang.startsWith('en') &&
            (v.name.includes('David') || v.name.includes('Guy') || v.name.includes('Male') || v.name.includes('Arthur') || v.name.includes('Google UK English Male'))
        );
        const hiVoice = this._voices.find((v) => v.lang.startsWith('hi') || v.lang.toLowerCase().includes('hindi'));
        const fallback = this._voices.find(
          (v) => v.lang.startsWith('en') && (v.name.includes('Google') || v.name.includes('Microsoft'))
        );
        this._selectedVoice = preferred || hiVoice || fallback || this._voices[0];
      }
    };

    loadVoices();

    // Chrome fires this event asynchronously
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }

  async speak(text) {
    if (!window.speechSynthesis) return;
    
    // Stop any ongoing speech
    window.speechSynthesis.cancel();

    return new Promise((resolve, reject) => {
      const utterance = new SpeechSynthesisUtterance(text);
      if (this._selectedVoice) {
        utterance.voice = this._selectedVoice;
      }
      
      // If the text contains Devanagari/Hindi script, prefer a Hindi voice when available
      if (/[ऀ-ॿ]/.test(text) && this._voices.length > 0) {
        const hindiVoice = this._voices.find((v) => v.lang.startsWith('hi') || v.lang.toLowerCase().includes('hindi'));
        if (hindiVoice) utterance.voice = hindiVoice;
      }

      utterance.onstart = () => {
        this._emitState('speaking');
      };
      
      utterance.onend = () => {
        this._emitState('speech-end');
        resolve();
      };
      
      utterance.onerror = (err) => {
        console.error('[VoiceEngine] TTS Error:', err);
        this._emitState('speech-end');
        reject(err);
      };

      window.speechSynthesis.speak(utterance);
    });
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  /**
   * Toggle the waveform animation CSS class on the mic button.
   * @param {boolean} active
   */
  _toggleMicAnimation(active) {
    const micBtn = document.getElementById('mic-btn');
    if (micBtn) {
      micBtn.classList.toggle('listening', active);
    }
  }

  /**
   * Emit a state change to the registered callback.
   * @param {string} state
   */
  _emitState(state) {
    if (this._onStateChangeCallback) {
      this._onStateChangeCallback(state);
    }
  }

  /**
   * Show a notification through the global JarvisApp instance (if available).
   * Falls back to console.warn if no notification system is present.
   * @param {string} message
   * @param {string} type
   */
  _notify(message, type = 'info') {
    if (window.jarvis && typeof window.jarvis.showNotification === 'function') {
      window.jarvis.showNotification(message, type);
    } else {
      console.warn(`[VoiceEngine] ${type}: ${message}`);
    }
  }
}

// Expose globally (no bundler)
window.VoiceEngine = VoiceEngine;