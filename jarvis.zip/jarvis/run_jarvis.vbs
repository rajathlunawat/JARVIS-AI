Set WshShell = CreateObject("WScript.Shell")

' Set working directory to the backend folder
WshShell.CurrentDirectory = "c:\Users\rajat\OneDrive\Desktop\jarvis\backend"

' Start Ollama in the background for offline AI capabilities
WshShell.Run "cmd /c ollama serve", 0, False

' Wait 2 seconds to ensure Ollama is ready
WScript.Sleep 2000

' Launch JARVIS Electron App (this will start the server and the UI)
WshShell.Run "cmd /c npx electron main.js", 0, False
