const { exec } = require('child_process');
exec('start "" "notepad"', (err, stdout, stderr) => {
  if (err) console.error("Error:", err);
  else console.log("Success");
});
